# Project: Predict Solar Energy Generation Using Weather Data
# NOTE: This project uses simulated sample data for learning, not real weather measurements.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# 1. Load the dataset
df = pd.read_csv("solar_weather_dataset.csv")
print("First five rows:")
print(df.head())

print("\nDataset information:")
print(df.info())

# 2. Check missing values
print("\nMissing values in each column:")
print(df.isnull().sum())

# 3. Basic statistical analysis
print("\nStatistical summary:")
print(df.describe())

# 4. Select weather features and target
features = [
    "Temperature_C",
    "Sunlight_Hours",
    "Humidity_Percent",
    "Wind_Speed_kmh",
    "Cloud_Cover_Percent"
]
X = df[features]
y = df["Solar_Energy_kWh"]

# 5. Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 6. Train the Multiple Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 7. Predict solar energy for test data
y_pred = model.predict(X_test)

# 8. Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\nModel Evaluation:")
print("Mean Absolute Error (MAE):", round(mae, 3), "kWh")
print("Root Mean Squared Error (RMSE):", round(rmse, 3), "kWh")
print("R-squared score:", round(r2, 3))

# 9. Display actual and predicted values
results = pd.DataFrame({
    "Actual_kWh": y_test.to_numpy(),
    "Predicted_kWh": y_pred
})
print("\nActual and predicted values (first 10):")
print(results.head(10))

# 10. Plot sunlight hours against energy generation
plt.figure(figsize=(7, 5))
plt.scatter(df["Sunlight_Hours"], df["Solar_Energy_kWh"])
plt.xlabel("Sunlight Hours")
plt.ylabel("Solar Energy (kWh)")
plt.title("Sunlight Hours vs Solar Energy Generation")
plt.tight_layout()
plt.savefig("sunlight_vs_energy.png")
plt.show()

# 11. Plot actual vs predicted values
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred)
lower = min(y_test.min(), y_pred.min())
upper = max(y_test.max(), y_pred.max())
plt.plot([lower, upper], [lower, upper])
plt.xlabel("Actual Solar Energy (kWh)")
plt.ylabel("Predicted Solar Energy (kWh)")
plt.title("Actual vs Predicted Solar Energy")
plt.tight_layout()
plt.savefig("actual_vs_predicted.png")
plt.show()

# 12. Predict for a new example (edit these values as needed)
new_weather = pd.DataFrame([{
    "Temperature_C": 31.0,
    "Sunlight_Hours": 7.0,
    "Humidity_Percent": 55.0,
    "Wind_Speed_kmh": 10.0,
    "Cloud_Cover_Percent": 20.0
}])
new_prediction = model.predict(new_weather)[0]
print("\nExample weather input:", new_weather.to_dict(orient="records")[0])
print("Predicted solar energy:", round(new_prediction, 2), "kWh")
