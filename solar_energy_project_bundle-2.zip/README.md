# Predict Solar Energy Generation Using Weather Data

## Objective
Predict solar energy generation (kWh) using weather features with Multiple Linear Regression.

## Dataset
`solar_weather_dataset.csv` contains 240 sample rows. Columns include temperature, sunlight hours, humidity, wind speed, cloud cover, and solar energy generation.

**Important:** The dataset is simulated for educational practice. It is not collected from real weather stations and should not be used for real-world operational decisions.

## Techniques
- Data loading and basic cleaning checks using Pandas
- Descriptive statistics
- Train/test split (80% / 20%)
- Multiple Linear Regression using scikit-learn
- Evaluation using MAE, RMSE, and R-squared
- Visualizations using Matplotlib

## Example evaluation results
- MAE: 1.750 kWh
- RMSE: 2.246 kWh
- R-squared: 0.978

These scores describe performance on the generated sample data only.

## Files
- `solar_weather_dataset.csv` — simulated sample dataset
- `solar_energy_prediction.py` — complete source code
- `outputs/` — example plots and prediction results
- `one_page_project_writeup.pdf` — project summary
- `source_code_and_output.pdf` — code and example output/plots

## Run the project
Install dependencies:
```bash
pip install pandas numpy matplotlib scikit-learn reportlab
```
Place the Python file and CSV in the same folder, then run:
```bash
python solar_energy_prediction.py
```
